package com.example.universdecuriositats.data
// Variables para crear una lista de Planetas
data class Planeta(
    val id: Int,
    val nom: String,
    val descripcioBreu: String,
    val descripcioLlarga: String,
    val nomImatge: String
)